# simple
Cracl Simple Ngab

$ git clone https://github.com/YumasaaTzy/simple

$ cd simple

$ python KREK.py
